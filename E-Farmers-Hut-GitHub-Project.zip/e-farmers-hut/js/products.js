// Sample catalogue data. Edit this array to add or update products.
const products = [
  {id:1,name:"Fresh Tomatoes",category:"Vegetables",price:35,unit:"kg",emoji:"🍅",tag:"Popular",farmer:"Green Valley Farm"},
  {id:2,name:"Organic Spinach",category:"Vegetables",price:25,unit:"bunch",emoji:"🥬",tag:"Fresh today",farmer:"Lakshmi Farms"},
  {id:3,name:"Carrots",category:"Vegetables",price:40,unit:"kg",emoji:"🥕",tag:"",farmer:"Green Valley Farm"},
  {id:4,name:"Farm Potatoes",category:"Vegetables",price:30,unit:"kg",emoji:"🥔",tag:"",farmer:"Sri Sai Farm"},
  {id:5,name:"Sweet Bananas",category:"Fruits",price:50,unit:"dozen",emoji:"🍌",tag:"Popular",farmer:"Mango Grove"},
  {id:6,name:"Fresh Apples",category:"Fruits",price:140,unit:"kg",emoji:"🍎",tag:"",farmer:"Hilltop Orchard"},
  {id:7,name:"Seasonal Mangoes",category:"Fruits",price:90,unit:"kg",emoji:"🥭",tag:"Seasonal",farmer:"Mango Grove"},
  {id:8,name:"Basmati Rice",category:"Grains",price:85,unit:"kg",emoji:"🌾",tag:"",farmer:"Annapurna Fields"},
  {id:9,name:"Whole Wheat",category:"Grains",price:42,unit:"kg",emoji:"🌾",tag:"",farmer:"Annapurna Fields"},
  {id:10,name:"Fresh Milk",category:"Dairy",price:32,unit:"500 ml",emoji:"🥛",tag:"Daily",farmer:"Happy Cow Dairy"},
  {id:11,name:"Farm Curd",category:"Dairy",price:38,unit:"500 g",emoji:"🥣",tag:"",farmer:"Happy Cow Dairy"},
  {id:12,name:"Green Chillies",category:"Vegetables",price:45,unit:"kg",emoji:"🌶️",tag:"",farmer:"Lakshmi Farms"}
];
