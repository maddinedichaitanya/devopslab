const $ = (selector) => document.querySelector(selector);
const money = (value) => `₹${value.toLocaleString("en-IN")}`;
let cart = [];
let activeCategory = "All";

function renderProducts() {
  const term = $("#searchInput").value.trim().toLowerCase();
  const filtered = products.filter(p =>
    (activeCategory === "All" || p.category === activeCategory) &&
    (p.name.toLowerCase().includes(term) || p.category.toLowerCase().includes(term) || p.farmer.toLowerCase().includes(term))
  );
  $("#productGrid").innerHTML = filtered.map(p => `
    <article class="product-card">
      <div class="product-image"><span>${p.emoji}</span>${p.tag ? `<span class="tag">${p.tag}</span>` : ""}</div>
      <div class="product-info">
        <span class="product-category">${p.category}</span><h3>${p.name}</h3>
        <small class="muted">By ${p.farmer}</small>
        <div class="product-meta"><span class="price">${money(p.price)} <span class="unit">/ ${p.unit}</span></span>
          <button class="add-button" data-add="${p.id}">+ Add</button></div>
      </div>
    </article>`).join("");
  $("#emptyState").classList.toggle("hidden", filtered.length !== 0);
}
function addToCart(id) {
  const item = cart.find(x => x.id === id);
  if (item) item.qty++;
  else cart.push({id, qty:1});
  renderCart(); showToast("Added to your cart");
}
function changeQty(id, amount) {
  const item = cart.find(x => x.id === id);
  if (!item) return;
  item.qty += amount;
  if (item.qty <= 0) cart = cart.filter(x => x.id !== id);
  renderCart();
}
function removeItem(id) { cart = cart.filter(x => x.id !== id); renderCart(); }
function renderCart() {
  const count = cart.reduce((sum, item) => sum + item.qty, 0);
  const total = cart.reduce((sum, item) => sum + products.find(p => p.id === item.id).price * item.qty, 0);
  $("#cartCount").textContent = count;
  $("#cartSubtotal").textContent = money(total);
  $("#dialogTotal").textContent = money(total);
  $("#cartItems").innerHTML = cart.length ? cart.map(item => {
    const p = products.find(x => x.id === item.id);
    return `<div class="cart-row"><span class="cart-emoji">${p.emoji}</span><div><h4>${p.name}</h4><small>${money(p.price)} / ${p.unit}</small><div class="quantity"><button data-minus="${p.id}" aria-label="Decrease quantity">−</button><span>${item.qty}</span><button data-plus="${p.id}" aria-label="Increase quantity">+</button></div></div><div><strong>${money(p.price * item.qty)}</strong><br><button class="remove-button" data-remove="${p.id}">Remove</button></div></div>`;
  }).join("") : '<p class="muted">Your cart is empty. Add some fresh produce!</p>';
  $("#checkoutButton").disabled = cart.length === 0;
  $("#checkoutButton").style.opacity = cart.length ? "1" : ".5";
}
function openCart() { $("#cartDrawer").classList.add("open"); $("#cartDrawer").setAttribute("aria-hidden","false"); $("#backdrop").classList.remove("hidden"); }
function closeCart() { $("#cartDrawer").classList.remove("open"); $("#cartDrawer").setAttribute("aria-hidden","true"); $("#backdrop").classList.add("hidden"); }
let toastTimer;
function showToast(message) { const toast=$("#toast"); toast.textContent=message; toast.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>toast.classList.remove("show"),2200); }

$("#productGrid").addEventListener("click", e => { const button=e.target.closest("[data-add]"); if(button) addToCart(Number(button.dataset.add)); });
$("#cartItems").addEventListener("click", e => {
  const b=e.target.closest("button"); if(!b) return;
  if(b.dataset.plus) changeQty(Number(b.dataset.plus),1);
  if(b.dataset.minus) changeQty(Number(b.dataset.minus),-1);
  if(b.dataset.remove) removeItem(Number(b.dataset.remove));
});
$("#categoryFilters").addEventListener("click", e => {
  const b=e.target.closest("[data-category]"); if(!b) return;
  activeCategory=b.dataset.category;
  document.querySelectorAll(".filter").forEach(x=>x.classList.toggle("active",x===b));
  renderProducts();
});
$("#searchInput").addEventListener("input",renderProducts);
$("#cartButton").addEventListener("click",openCart);
$("#closeCart").addEventListener("click",closeCart);
$("#backdrop").addEventListener("click",closeCart);
$("#menuToggle").addEventListener("click",()=>$("#mainNav").classList.toggle("show"));
$("#mainNav").addEventListener("click",e=>{if(e.target.tagName==="A")$("#mainNav").classList.remove("show");});
$("#checkoutButton").addEventListener("click",()=>{if(cart.length){closeCart();$("#checkoutDialog").showModal();}});
$("#closeCheckout").addEventListener("click",()=>$("#checkoutDialog").close());
$("#checkoutForm").addEventListener("submit",e=>{
  e.preventDefault();
  const form=new FormData(e.target);
  const orderId="EFH"+Date.now().toString().slice(-6);
  $("#checkoutDialog").close();
  alert(`Thank you, ${form.get("name")}! Your demo order ${orderId} has been placed. No payment was processed.`);
  cart=[]; renderCart(); e.target.reset();
});
$("#year").textContent=new Date().getFullYear();
renderProducts(); renderCart();
