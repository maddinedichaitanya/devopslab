# E-Farmers Hut 🌱

A responsive farmer-focused e-commerce marketplace front end built with **HTML, CSS and vanilla JavaScript**. This project is suitable as a college mini/final-year project starting point and for publishing to GitHub.

## Features

- Responsive landing page and product catalogue
- Product categories: vegetables, fruits, grains and dairy
- Live product search by name, category or farmer
- Add-to-cart, quantity controls, remove item and subtotal
- Demo checkout form with basic browser validation
- Mobile navigation and shopping-cart drawer
- Sample product data kept separately in `js/products.js`

## Project structure

```text
e-farmers-hut/
├── index.html
├── css/
│   └── style.css
├── js/
│   ├── products.js
│   └── app.js
└── README.md
```

## Run locally

1. Download and extract the ZIP file.
2. Open the `e-farmers-hut` folder.
3. Double-click `index.html` to open it in a modern browser.

Recommended: use Visual Studio Code with the **Live Server** extension, right-click `index.html`, and select **Open with Live Server**.

No build tools or package installation are required.

## Publish to GitHub

### Option A: GitHub website

1. Sign in to [GitHub](https://github.com/).
2. Click **New repository** and give it a name such as `e-farmers-hut`.
3. Choose Public or Private, then create the repository.
4. Extract this ZIP on your computer.
5. In the repository, select **Add file → Upload files**.
6. Upload the files and folders from the extracted project (not the ZIP itself).
7. Add a commit message such as `Add E-Farmers Hut e-commerce website` and commit.

### Option B: Git command line

Open a terminal inside the extracted project folder:

```bash
git init
git add .
git commit -m "Initial commit: E-Farmers Hut"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/e-farmers-hut.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username and make sure the repository exists first.

## Customize products

Open `js/products.js`. Add a product object to the `products` array using this format:

```js
{
  id: 13,
  name: "Fresh Okra",
  category: "Vegetables",
  price: 40,
  unit: "kg",
  emoji: "🥬",
  tag: "Fresh today",
  farmer: "Sample Farm"
}
```

Use a unique numeric `id`. Supported categories are `Vegetables`, `Fruits`, `Grains`, and `Dairy` (you can add more categories in the HTML filter buttons).

## Important project notes

This is a **front-end demonstration**, not a production-ready online store:
- Product and cart data are held in JavaScript memory and reset when the page reloads.
- Checkout only displays a demo confirmation; it does not process payments or create a real order.
- There is no user authentication, database, admin panel, inventory management, delivery integration or backend API.
- The sample farmer names, products and prices are illustrative. Update them with verified project data.
- Do not collect real customer information or connect real payments until a secure backend, privacy safeguards and payment-provider integration have been implemented.

## Suggested future enhancements

1. Add a backend using Node.js/Express or PHP.
2. Store products, farmers, users and orders in MySQL or MongoDB.
3. Add secure login and role-based farmer/admin dashboards.
4. Integrate a trusted payment gateway in test mode first.
5. Add order tracking, stock management and delivery status.
6. Add product images with appropriate licenses and farmer profiles.

## License

For educational use. Add a license file if you want to specify reuse and distribution terms.
